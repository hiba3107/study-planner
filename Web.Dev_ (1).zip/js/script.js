"use strict";

const DATA_URL = "data/assessments.json";

let assessments = [];
let tasks = JSON.parse(localStorage.getItem("revisionTasks")) || [];
let goalGrade = localStorage.getItem("goalGrade") || "";
let grades = JSON.parse(localStorage.getItem("moduleGrades")) || {};
let darkMode = localStorage.getItem("darkMode") === "true";

let currentDate = new Date();
currentDate = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1);

let timer = null;
let timeLeft = 25 * 60;
let totalTime = 25 * 60;
let timerRunning = false;
let timerPaused = false;

let barChartInstance = null;
let lineChartInstance = null;
let notifOpen = false;
let pendingRemoveId = null;

const calendarBody = document.getElementById("calendarBody");
const monthTitle = document.getElementById("monthTitle");
const prevMonthBtn = document.getElementById("prevMonthBtn");
const nextMonthBtn = document.getElementById("nextMonthBtn");

const taskForm = document.getElementById("taskForm");
const taskDescription = document.getElementById("taskDescription");
const taskUrl = document.getElementById("taskUrl");
const taskDueDate = document.getElementById("taskDueDate");
const taskCompletionDate = document.getElementById("taskCompletionDate");
const taskList = document.getElementById("taskList");
const taskMessage = document.getElementById("taskMessage");
const overdueBox = document.getElementById("overdueBox");

const next30List = document.getElementById("next30List");

const goalSelect = document.getElementById("goalSelect");
const saveGoalBtn = document.getElementById("saveGoalBtn");
const goalText = document.getElementById("goalText");
const progressFill = document.getElementById("progressFill");

const gradesContainer = document.getElementById("gradesContainer");

const timerInput = document.getElementById("timerInput");
const volumeControl = document.getElementById("volumeControl");
const startTimerBtn = document.getElementById("startTimerBtn");
const pauseTimerBtn = document.getElementById("pauseTimerBtn");
const resumeTimerBtn = document.getElementById("resumeTimerBtn");
const resetTimerBtn = document.getElementById("resetTimerBtn");
const timerDisplay = document.getElementById("timerDisplay");
const timerMessage = document.getElementById("timerMessage");
const timerProgressFill = document.getElementById("timerProgressFill");
const timerStatus = document.getElementById("timerStatus");
const timerBox = document.getElementById("timerBox");

prevMonthBtn.addEventListener("click", goToPreviousMonth);
nextMonthBtn.addEventListener("click", goToNextMonth);
taskForm.addEventListener("submit", addTask);
saveGoalBtn.addEventListener("click", saveGoal);
startTimerBtn.addEventListener("click", startTimer);
pauseTimerBtn.addEventListener("click", pauseTimer);
resumeTimerBtn.addEventListener("click", resumeTimer);
resetTimerBtn.addEventListener("click", resetTimer);
timerInput.addEventListener("change", resetTimer);

document.getElementById("notifBtn").addEventListener("click", function() {
    let panel = document.getElementById("notifPanel");
    if (notifOpen) {
        panel.style.display = "none";
        notifOpen = false;
    } else {
        panel.style.display = "block";
        notifOpen = true;
        buildNotifications();
    }
});

document.getElementById("darkModeBtn").addEventListener("click", function() {
    darkMode = !darkMode;
    localStorage.setItem("darkMode", darkMode);
    applyDarkMode();
});

document.getElementById("printBtn").addEventListener("click", function(e) {
    e.preventDefault();
    window.print();
});

document.getElementById("confirmYes").addEventListener("click", function() {
    if (pendingRemoveId !== null) {
        doRemoveTask(pendingRemoveId);
        pendingRemoveId = null;
    }
    document.getElementById("confirmModal").classList.remove("show");
});

document.getElementById("confirmNo").addEventListener("click", function() {
    pendingRemoveId = null;
    document.getElementById("confirmModal").classList.remove("show");
});

document.getElementById("taskSearch").addEventListener("input", function() {
    let searchVal = this.value.toLowerCase();
    let items = document.querySelectorAll("#taskList li");

    items.forEach(function(li) {
        let text = li.textContent.toLowerCase();
        if (text.includes(searchVal)) {
            li.style.display = "flex";
        } else {
            li.style.display = "none";
        }
    });
});

function applyDarkMode() {
    if (darkMode) {
        document.body.classList.add("dark");
        document.getElementById("darkModeBtn").textContent = "☀️ Light Mode";
    } else {
        document.body.classList.remove("dark");
        document.getElementById("darkModeBtn").textContent = "🌙 Dark Mode";
    }
}

function showWelcomeMessage() {
    let hour = new Date().getHours();
    let greeting = "";

    if (hour < 12) {
        greeting = "Good morning";
    } else if (hour < 17) {
        greeting = "Good afternoon";
    } else {
        greeting = "Good evening";
    }

    let today = new Date();
    today.setHours(0, 0, 0, 0);

    let in7Days = new Date(today);
    in7Days.setDate(today.getDate() + 7);

    let thisWeekCount = 0;

    for (let i = 0; i < assessments.length; i++) {
        let due = new Date(assessments[i].deadline);
        due.setHours(0, 0, 0, 0);
        if (due >= today && due <= in7Days) {
            thisWeekCount++;
        }
    }

    let msg = greeting + "! ";

    if (thisWeekCount > 0) {
        msg += "You have " + thisWeekCount + " deadline(s) this week. Stay focused! 💪";
    } else {
        msg += "No deadlines this week. Keep up the good work! 🌟";
    }

    document.getElementById("welcomeMsg").textContent = msg;
}

function goToPreviousMonth() {
    currentDate = new Date(currentDate.getFullYear(), currentDate.getMonth() - 1, 1);
    showCalendar();
}

function goToNextMonth() {
    currentDate = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 1);
    showCalendar();
}

function makeDateString(date) {
    let year = date.getFullYear();
    let month = String(date.getMonth() + 1).padStart(2, "0");
    let day = String(date.getDate()).padStart(2, "0");
    return year + "-" + month + "-" + day;
}

function getMonthName(date) {
    return date.toLocaleString("en-GB", {
        month: "long",
        year: "numeric"
    });
}

function loadAssessments() {
    fetch(DATA_URL)
        .then(function(response) {
            return response.json();
        })
        .then(function(data) {
            assessments = data;
            startWebsite();
        })
        .catch(function() {
            calendarBody.innerHTML = "<tr><td colspan='7'>Could not load assessments file.</td></tr>";
        });
}

function startWebsite() {
    applyDarkMode();
    showWelcomeMessage();
    showCalendar();
    showTasks();
    showNext30Days();
    showGrades();
    showGoal();
    resetTimer();
    showCharts();
}

function groupAssessmentsByDate() {
    let grouped = {};

    for (let i = 0; i < assessments.length; i++) {
        let item = assessments[i];
        let date = item.deadline;

        if (grouped[date] === undefined) {
            grouped[date] = [];
        }

        grouped[date].push(item);
    }

    return grouped;
}

function showCalendar() {
    calendarBody.innerHTML = "";
    monthTitle.textContent = getMonthName(currentDate);

    let grouped = groupAssessmentsByDate();

    let year = currentDate.getFullYear();
    let month = currentDate.getMonth();

    let firstDay = new Date(year, month, 1).getDay();
    let daysInMonth = new Date(year, month + 1, 0).getDate();
    let totalCells = Math.ceil((firstDay + daysInMonth) / 7) * 7;

    let today = new Date();
    today.setHours(0, 0, 0, 0);

    let dayNumber = 1;

    for (let i = 0; i < totalCells / 7; i++) {
        let row = document.createElement("tr");

        for (let j = 0; j < 7; j++) {
            let cell = document.createElement("td");
            let cellPosition = i * 7 + j;

            if (cellPosition < firstDay || dayNumber > daysInMonth) {
                cell.classList.add("muted");
            } else {
                let dayNumberDiv = document.createElement("div");
                dayNumberDiv.className = "dayNum";
                dayNumberDiv.textContent = dayNumber;
                cell.appendChild(dayNumberDiv);

                let fullDate = new Date(year, month, dayNumber);
                let dateString = makeDateString(fullDate);

                if (grouped[dateString] !== undefined) {
                    for (let k = 0; k < grouped[dateString].length; k++) {
                        let item = grouped[dateString][k];
                        let div = document.createElement("div");

                        if (item.type === "exam") {
                            div.className = "deadlineItem examItem";
                        } else {
                            div.className = "deadlineItem cwItem";
                        }

                        let typeDiv = document.createElement("div");
                        typeDiv.className = "deadlineType";
                        typeDiv.textContent = item.type;

                        let nameDiv = document.createElement("div");
                        nameDiv.textContent = item.assessmentName;

                        div.appendChild(typeDiv);
                        div.appendChild(nameDiv);

                        let daysAway = Math.ceil((fullDate - today) / (1000 * 60 * 60 * 24));

                        if (daysAway >= 0 && daysAway <= 7) {
                            let countdown = document.createElement("div");
                            countdown.className = "countdown-soon";
                            countdown.textContent = daysAway === 0 ? "TODAY!" : daysAway + " days left!";
                            div.appendChild(countdown);
                        }

                        cell.appendChild(div);
                    }
                }

                for (let t = 0; t < tasks.length; t++) {
                    if (tasks[t].dueDate === dateString) {
                        let taskDiv = document.createElement("div");
                        taskDiv.className = "deadlineItem taskItem";
                        taskDiv.textContent = "Task: " + tasks[t].description;
                        cell.appendChild(taskDiv);
                    }
                }

                dayNumber++;
            }

            row.appendChild(cell);
        }

        calendarBody.appendChild(row);
    }
}

function addTask(event) {
    event.preventDefault();

    let description = taskDescription.value.trim();
    let url = taskUrl.value.trim();
    let dueDate = taskDueDate.value;
    let completionDate = taskCompletionDate.value;

    taskMessage.textContent = "";

    if (description === "") {
        taskMessage.textContent = "Please enter a task description.";
        taskMessage.style.color = "red";
        return;
    }

    if (description.includes("<") || description.includes(">")) {
        taskMessage.textContent = "Description cannot contain HTML tags.";
        taskMessage.style.color = "red";
        return;
    }

    if (dueDate === "") {
        taskMessage.textContent = "Please choose a due date.";
        taskMessage.style.color = "red";
        return;
    }

    let today = makeDateString(new Date());

    if (dueDate < today) {
        taskMessage.textContent = "Due date cannot be in the past.";
        taskMessage.style.color = "red";
        return;
    }

    let newTask = {
        id: Date.now(),
        description: description,
        url: url,
        dueDate: dueDate,
        completionDate: completionDate
    };

    tasks.push(newTask);
    saveTasksToStorage();
    showTasks();
    showNext30Days();
    showCalendar();

    taskForm.reset();
    taskMessage.textContent = "Task added successfully.";
    taskMessage.style.color = "green";
}

function removeTask(taskId) {
    pendingRemoveId = taskId;
    document.getElementById("confirmText").textContent = "Are you sure you want to remove this task?";
    document.getElementById("confirmModal").classList.add("show");
}

function doRemoveTask(taskId) {
    let newTasks = [];

    for (let i = 0; i < tasks.length; i++) {
        if (tasks[i].id !== taskId) {
            newTasks.push(tasks[i]);
        }
    }

    tasks = newTasks;
    saveTasksToStorage();
    showTasks();
    showNext30Days();
    showCalendar();
    taskMessage.textContent = "Task removed.";
    taskMessage.style.color = "green";
}

function markTaskComplete(taskId) {
    for (let i = 0; i < tasks.length; i++) {
        if (tasks[i].id === taskId) {
            tasks[i].completionDate = makeDateString(new Date());
        }
    }

    saveTasksToStorage();
    showTasks();
    showNext30Days();
    showCalendar();
    taskMessage.textContent = "Task marked as complete! 🎉";
    taskMessage.style.color = "green";
    launchFireworks();
}

function saveTasksToStorage() {
    localStorage.setItem("revisionTasks", JSON.stringify(tasks));
}

function showTasks() {
    taskList.innerHTML = "";

    tasks.sort(function(a, b) {
        return new Date(a.dueDate) - new Date(b.dueDate);
    });

    let today = makeDateString(new Date());
    let overdueCount = 0;

    for (let i = 0; i < tasks.length; i++) {
        let task = tasks[i];
        let li = document.createElement("li");
        li.classList.add("task-slide-in");

        let text = task.description + " | Due: " + task.dueDate;

        if (task.url !== "") {
            text = text + " | Link: " + task.url;
        }

        if (task.completionDate !== "") {
            text = text + " | Completed: " + task.completionDate;
            li.style.borderLeft = "4px solid #27ae60";
            li.style.backgroundColor = "#f0fff4";
        }

        if (task.dueDate < today && task.completionDate === "") {
            text = text + " | OVERDUE";
            li.style.borderLeft = "4px solid red";
            li.style.backgroundColor = "#fff5f5";
            overdueCount++;
        }

        let textSpan = document.createElement("span");
        textSpan.textContent = text;

        let showOnCalBtn = document.createElement("button");
        showOnCalBtn.textContent = "📅 Calendar";
        showOnCalBtn.type = "button";
        showOnCalBtn.className = "cal-btn";

        showOnCalBtn.addEventListener("click", function() {
            currentDate = new Date(task.dueDate.substring(0, 7) + "-01");
            showCalendar();
            document.getElementById("calendar").scrollIntoView();
        });

        let completeBtn = document.createElement("button");
        completeBtn.textContent = "✅ Done";
        completeBtn.type = "button";
        completeBtn.className = "complete-btn";

        if (task.completionDate !== "") {
            completeBtn.disabled = true;
            completeBtn.style.opacity = "0.5";
        }

        completeBtn.addEventListener("click", function() {
            markTaskComplete(task.id);
        });

        let removeButton = document.createElement("button");
        removeButton.textContent = "🗑️ Remove";
        removeButton.type = "button";
        removeButton.className = "remove-btn";

        removeButton.addEventListener("click", function() {
            removeTask(task.id);
        });

        li.appendChild(textSpan);
        li.appendChild(showOnCalBtn);
        li.appendChild(completeBtn);
        li.appendChild(removeButton);
        taskList.appendChild(li);
    }

    if (overdueCount > 0) {
        overdueBox.textContent = "⚠️ You have " + overdueCount + " overdue revision task(s). Please catch up!";
        overdueBox.style.backgroundColor = "#fff5f5";
        overdueBox.style.borderLeftColor = "#e74c3c";
        overdueBox.style.color = "#c0392b";
    } else {
        overdueBox.textContent = "✅ No overdue revision tasks. Well done!";
        overdueBox.style.backgroundColor = "#f0fff4";
        overdueBox.style.borderLeftColor = "#27ae60";
        overdueBox.style.color = "#27ae60";
    }
}

function showNext30Days() {
    next30List.innerHTML = "";

    let today = new Date();
    today.setHours(0, 0, 0, 0);

    let next30 = new Date();
    next30.setHours(0, 0, 0, 0);
    next30.setDate(next30.getDate() + 30);

    let upcoming = [];

    for (let i = 0; i < assessments.length; i++) {
        let itemDate = new Date(assessments[i].deadline);
        itemDate.setHours(0, 0, 0, 0);

        if (itemDate >= today && itemDate <= next30) {
            upcoming.push({
                date: assessments[i].deadline,
                text: assessments[i].assessmentName + " (" + assessments[i].module + ") - " + assessments[i].deadline
            });
        }
    }

    for (let i = 0; i < tasks.length; i++) {
        let taskDate = new Date(tasks[i].dueDate);
        taskDate.setHours(0, 0, 0, 0);

        if (taskDate >= today && taskDate <= next30 && tasks[i].completionDate === "") {
            upcoming.push({
                date: tasks[i].dueDate,
                text: "Revision Task: " + tasks[i].description + " - " + tasks[i].dueDate
            });
        }
    }

    upcoming.sort(function(a, b) {
        return new Date(a.date) - new Date(b.date);
    });

    if (upcoming.length === 0) {
        let li = document.createElement("li");
        li.textContent = "Nothing due in the next 30 days.";
        next30List.appendChild(li);
        return;
    }

    let heading = document.createElement("p");
    heading.textContent = "You have " + upcoming.length + " deadline(s) or task(s) coming up in the next 30 days:";
    heading.style.fontWeight = "600";
    heading.style.marginBottom = "10px";
    next30List.appendChild(heading);

    for (let i = 0; i < upcoming.length; i++) {
        let li = document.createElement("li");
        li.textContent = upcoming[i].text;
        next30List.appendChild(li);
    }
}

function saveGoal() {
    let value = goalSelect.value;

    if (value === "") {
        goalText.textContent = "Please select a grade goal.";
        goalText.style.color = "red";
        return;
    }

    goalGrade = value;
    localStorage.setItem("goalGrade", goalGrade);
    showGoal();
    showCharts();
}

function getGradeBoundaries() {
    return {
        "third": { min: 40, max: 49, label: "Third Class (40-49%)" },
        "two-two": { min: 50, max: 59, label: "2:2 (50-59%)" },
        "two-one": { min: 60, max: 69, label: "2:1 (60-69%)" },
        "first": { min: 70, max: 100, label: "First Class (70%+)" }
    };
}

function getModules() {
    let modules = {};

    for (let i = 0; i < assessments.length; i++) {
        let item = assessments[i];

        if (modules[item.module] === undefined) {
            modules[item.module] = [];
        }

        modules[item.module].push(item);
    }

    return modules;
}

function saveGradesToStorage() {
    localStorage.setItem("moduleGrades", JSON.stringify(grades));
}

function showGrades() {
    gradesContainer.innerHTML = "";

    let modules = getModules();

    for (let moduleName in modules) {
        let box = document.createElement("div");
        box.className = "grade-box";

        let title = document.createElement("h3");
        title.textContent = moduleName;
        box.appendChild(title);

        let items = modules[moduleName];

        for (let i = 0; i < items.length; i++) {
            let assessment = items[i];

            let label = document.createElement("label");
            label.textContent = assessment.assessmentName + " (" + Math.round(assessment.weighting * 100) + "%)";
            box.appendChild(label);

            let input = document.createElement("input");
            input.type = "number";
            input.min = "0";
            input.max = "100";
            input.step = "1";
            input.placeholder = "0-100";

            let assessmentId = assessment.id;

            if (grades[assessmentId] !== undefined) {
                input.value = grades[assessmentId];
            }

            input.addEventListener("input", function() {
                let mark = parseInt(this.value);

                if (this.value === "") {
                    delete grades[assessmentId];
                } else if (isNaN(mark) || mark < 0) {
                    this.value = 0;
                    grades[assessmentId] = 0;
                } else if (mark > 100) {
                    this.value = 100;
                    grades[assessmentId] = 100;
                } else {
                    grades[assessmentId] = mark;
                }

                saveGradesToStorage();
                showGrades();
                showGoal();
                showCharts();
            });

            box.appendChild(input);
        }

        let totalGrade = 0;
        let fullWeight = 0;

        for (let i = 0; i < items.length; i++) {
            fullWeight += items[i].weighting;
            if (grades[items[i].id] !== undefined) {
                totalGrade += grades[items[i].id] * items[i].weighting;
            }
        }

        let result = document.createElement("p");

        if (totalGrade === 0) {
            result.textContent = "Module grade: no marks entered yet";
        } else {
            result.textContent = "Module grade so far: " + (totalGrade / fullWeight).toFixed(1) + "%";
        }

        box.appendChild(result);
        gradesContainer.appendChild(box);
    }
}

function getAverageGrade() {
    let modules = getModules();
    let moduleNames = Object.keys(modules);

    if (moduleNames.length === 0) {
        return 0;
    }

    let total = 0;

    for (let i = 0; i < moduleNames.length; i++) {
        let oneModule = modules[moduleNames[i]];
        let moduleGrade = 0;
        let fullWeight = 0;

        for (let j = 0; j < oneModule.length; j++) {
            fullWeight += oneModule[j].weighting;
        }

        for (let j = 0; j < oneModule.length; j++) {
            let assessment = oneModule[j];
            if (grades[assessment.id] !== undefined) {
                moduleGrade += grades[assessment.id] * assessment.weighting;
            }
        }

        total += moduleGrade / fullWeight;
    }

    return total / moduleNames.length;
}

function showGoal() {
    let boundaries = getGradeBoundaries();

    if (goalGrade === "") {
        goalText.textContent = "No goal selected yet.";
        progressFill.style.width = "0%";
        progressFill.textContent = "";
        return;
    }

    if (goalSelect.value !== goalGrade) {
        goalSelect.value = goalGrade;
    }

    let boundary = boundaries[goalGrade];
    let currentAverage = getAverageGrade();
    let targetMin = boundary.min;
    let progress = 0;

    if (targetMin > 0) {
        progress = (currentAverage / targetMin) * 100;
    }

    if (progress > 100) {
        progress = 100;
    }

    if (currentAverage >= boundary.min) {
        goalText.textContent = "✅ On track! Current average: " + currentAverage.toFixed(1) + "% — you are meeting your goal of " + boundary.label;
        goalText.style.color = "#27ae60";
    } else {
        goalText.textContent = "📈 Current average: " + currentAverage.toFixed(1) + "% — you need " + boundary.min + "% to reach " + boundary.label;
        goalText.style.color = "#c0392b";
    }

    progressFill.style.width = progress.toFixed(0) + "%";
    progressFill.textContent = progress.toFixed(0) + "%";
}

function showCharts() {
    let modules = getModules();
    let moduleNames = Object.keys(modules);
    let moduleAverages = [];

    for (let i = 0; i < moduleNames.length; i++) {
        let items = modules[moduleNames[i]];
        let total = 0;
        let fullWeight = 0;

        for (let j = 0; j < items.length; j++) {
            fullWeight += items[j].weighting;
            if (grades[items[j].id] !== undefined) {
                total += grades[items[j].id] * items[j].weighting;
            }
        }

        moduleAverages.push(fullWeight > 0 ? parseFloat((total / fullWeight).toFixed(1)) : 0);
    }

    let currentAvg = parseFloat(getAverageGrade().toFixed(1));
    let goalMin = 0;

    if (goalGrade !== "") {
        let boundaries = getGradeBoundaries();
        goalMin = boundaries[goalGrade].min;
    }

    let barCanvas = document.getElementById("barChart");

    if (barChartInstance) {
        barChartInstance.destroy();
    }

    barChartInstance = new Chart(barCanvas, {
        type: "bar",
        data: {
            labels: ["Current Average", "Goal Grade"],
            datasets: [{
                label: "Grade %",
                data: [currentAvg, goalMin],
                backgroundColor: [
                    "rgba(54, 162, 235, 0.7)",
                    "rgba(255, 99, 132, 0.7)"
                ],
                borderColor: [
                    "rgba(54, 162, 235, 1)",
                    "rgba(255, 99, 132, 1)"
                ],
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            scales: {
                y: {
                    beginAtZero: true,
                    max: 100
                }
            }
        }
    });

    let lineCanvas = document.getElementById("lineChart");

    if (lineChartInstance) {
        lineChartInstance.destroy();
    }

    lineChartInstance = new Chart(lineCanvas, {
        type: "line",
        data: {
            labels: moduleNames,
            datasets: [{
                label: "Module Average",
                data: moduleAverages,
                borderColor: "rgb(75, 192, 192)",
                backgroundColor: "rgba(75, 192, 192, 0.2)",
                tension: 0.4,
                fill: true
            }]
        },
        options: {
            responsive: true,
            scales: {
                y: {
                    beginAtZero: true,
                    max: 100
                }
            }
        }
    });
}

function buildNotifications() {
    let list = document.getElementById("notifList");
    list.innerHTML = "";

    let notifications = [];
    let today = new Date();
    today.setHours(0, 0, 0, 0);

    let in30 = new Date(today);
    in30.setDate(today.getDate() + 30);

    let todayStr = makeDateString(new Date());

    for (let i = 0; i < tasks.length; i++) {
        if (tasks[i].dueDate < todayStr && tasks[i].completionDate === "") {
            notifications.push("⚠️ Overdue task: " + tasks[i].description);
        }
    }

    for (let i = 0; i < assessments.length; i++) {
        let due = new Date(assessments[i].deadline);
        due.setHours(0, 0, 0, 0);
        if (due >= today && due <= in30) {
            let daysAway = Math.ceil((due - today) / (1000 * 60 * 60 * 24));
            notifications.push("📅 " + assessments[i].assessmentName + " due in " + daysAway + " day(s)");
        }
    }

    for (let i = 0; i < tasks.length; i++) {
        let due = new Date(tasks[i].dueDate);
        due.setHours(0, 0, 0, 0);
        if (due >= today && due <= in30 && tasks[i].completionDate === "") {
            let daysAway = Math.ceil((due - today) / (1000 * 60 * 60 * 24));
            notifications.push("✅ Task due in " + daysAway + " day(s): " + tasks[i].description);
        }
    }

    if (notifications.length === 0) {
        let li = document.createElement("li");
        li.textContent = "No notifications right now!";
        list.appendChild(li);
        return;
    }

    for (let i = 0; i < notifications.length; i++) {
        let li = document.createElement("li");
        li.textContent = notifications[i];
        list.appendChild(li);
    }
}

function showToast() {
    let toast = document.getElementById("timerToast");
    toast.classList.add("show");

    setTimeout(function() {
        toast.classList.remove("show");
    }, 4000);
}

function launchFireworks() {
    let canvas = document.getElementById("fireworksCanvas");
    let ctx = canvas.getContext("2d");

    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;

    let particles = [];

    for (let i = 0; i < 150; i++) {
        particles.push({
            x: Math.random() * canvas.width,
            y: Math.random() * canvas.height / 2,
            vx: (Math.random() - 0.5) * 6,
            vy: (Math.random() - 0.5) * 6,
            alpha: 1,
            color: "hsl(" + Math.random() * 360 + ", 100%, 60%)",
            size: Math.random() * 4 + 2
        });
    }

    function animate() {
        ctx.clearRect(0, 0, canvas.width, canvas.height);

        particles.forEach(function(p) {
            p.x += p.vx;
            p.y += p.vy;
            p.vy += 0.1;
            p.alpha -= 0.015;

            ctx.globalAlpha = p.alpha;
            ctx.fillStyle = p.color;
            ctx.beginPath();
            ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
            ctx.fill();
        });

        particles = particles.filter(function(p) {
            return p.alpha > 0;
        });

        if (particles.length > 0) {
            requestAnimationFrame(animate);
        } else {
            ctx.clearRect(0, 0, canvas.width, canvas.height);
        }
    }

    animate();
}

function updateTimerDisplay() {
    let minutes = Math.floor(timeLeft / 60);
    let seconds = timeLeft % 60;
    let minutesText = String(minutes).padStart(2, "0");
    let secondsText = String(seconds).padStart(2, "0");
    timerDisplay.textContent = minutesText + ":" + secondsText;
}

function updateTimerProgress() {
    let progress = 0;
    if (totalTime > 0) {
        progress = ((totalTime - timeLeft) / totalTime) * 100;
    }
    if (progress < 0) { progress = 0; }
    if (progress > 100) { progress = 100; }
    timerProgressFill.style.width = progress + "%";
}

function getTimerMins() {
    let mins = parseInt(timerInput.value);
    if (isNaN(mins) || mins < 15) {
        mins = 15;
        timerInput.value = 15;
    }
    if (mins > 40) {
        mins = 40;
        timerInput.value = 40;
    }
    return mins;
}

function playSound() {
    let audioContext = new (window.AudioContext || window.webkitAudioContext)();
    let oscillator = audioContext.createOscillator();
    let gainNode = audioContext.createGain();

    oscillator.connect(gainNode);
    gainNode.connect(audioContext.destination);

    oscillator.type = "sine";
    oscillator.frequency.value = 800;

    let volume = parseInt(volumeControl.value) / 100;
    gainNode.gain.value = volume;

    oscillator.start();
    gainNode.gain.exponentialRampToValueAtTime(0.00001, audioContext.currentTime + 1.2);
    oscillator.stop(audioContext.currentTime + 1.2);
}

function startTimer() {
    clearInterval(timer);

    let mins = getTimerMins();
    totalTime = mins * 60;
    timeLeft = totalTime;
    timerRunning = true;
    timerPaused = false;

    updateTimerDisplay();
    updateTimerProgress();

    timerMessage.textContent = "Study session started. Stay focused. 💪";
    timerStatus.textContent = "Status: Running";
    timerBox.classList.add("timer-running");

    timer = setInterval(function() {
        timeLeft--;
        updateTimerDisplay();
        updateTimerProgress();

        if (timeLeft <= 0) {
            clearInterval(timer);
            timeLeft = 0;
            timerRunning = false;
            timerPaused = false;

            updateTimerDisplay();
            updateTimerProgress();

            timerMessage.textContent = "Time is up. Study session complete. Well done! 🎉";
            timerStatus.textContent = "Status: Finished";
            timerBox.classList.remove("timer-running");

            playSound();
            showToast();
        }
    }, 1000);
}

function pauseTimer() {
    if (timerRunning === true) {
        clearInterval(timer);
        timerRunning = false;
        timerPaused = true;

        timerMessage.textContent = "Timer paused.";
        timerStatus.textContent = "Status: Paused";
        timerBox.classList.remove("timer-running");
    }
}

function resumeTimer() {
    if (timerPaused === true && timeLeft > 0) {
        timerRunning = true;
        timerPaused = false;

        timerMessage.textContent = "Timer resumed. Keep going! 💪";
        timerStatus.textContent = "Status: Running";
        timerBox.classList.add("timer-running");

        clearInterval(timer);

        timer = setInterval(function() {
            timeLeft--;
            updateTimerDisplay();
            updateTimerProgress();

            if (timeLeft <= 0) {
                clearInterval(timer);
                timeLeft = 0;
                timerRunning = false;
                timerPaused = false;

                updateTimerDisplay();
                updateTimerProgress();

                timerMessage.textContent = "Time is up. Study session complete. Well done! 🎉";
                timerStatus.textContent = "Status: Finished";
                timerBox.classList.remove("timer-running");

                playSound();
                showToast();
            }
        }, 1000);
    }
}

function resetTimer() {
    clearInterval(timer);

    let mins = getTimerMins();
    totalTime = mins * 60;
    timeLeft = totalTime;
    timerRunning = false;
    timerPaused = false;

    updateTimerDisplay();
    updateTimerProgress();

    timerMessage.textContent = "Choose a time and start your session.";
    timerStatus.textContent = "Status: Ready";
    timerBox.classList.remove("timer-running");
}

loadAssessments();